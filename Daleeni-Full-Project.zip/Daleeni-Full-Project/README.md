# دلّيني — مشروع Flutter

هذه الحزمة هي ملفات المصدر التي يجب وضع محتوياتها في جذر مستودع `Daleeni-Iraq`، وليس رفع ملف ZIP وحده.

## المحتويات
- واجهة عربية RTL وخريطة OpenStreetMap.
- أيقونة دلّيني المرفقة في `assets/daleeni_icon.png` وتوليد أيقونة Android أثناء البناء.
- تحديد الموقع عبر GPS.
- البحث عن وجهة ورسم مسار مبدئي عبر Nominatim وOSRM.
- GitHub Actions workflow لبناء APK ونشره في Releases.

## الملفات
- `pubspec.yaml`
- `lib/main.dart`
- `assets/daleeni_icon.png`
- `.github/workflows/build.yml`

## حدود النسخة
هذه نسخة أولية قابلة للبناء وليست بديلاً كاملاً عن Waze. بلاغات الطريق لا تُشارك بين المستخدمين بعد؛ يلزم خادم وقاعدة بيانات. خدمات Nominatim وOSRM العامة محدودة وليست ضماناً لخدمة إنتاجية. الخريطة تحتاج إنترنت وتعرض إسناد OpenStreetMap.
