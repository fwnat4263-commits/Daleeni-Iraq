import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';

void main() => runApp(const DaleeniApp());

class DaleeniApp extends StatelessWidget {
  const DaleeniApp({super.key});

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF1267E8);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دلّيني',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        fontFamily: 'Roboto',
      ),
      home: const DaleeniHome(),
    );
  }
}

class DaleeniHome extends StatefulWidget {
  const DaleeniHome({super.key});

  @override
  State<DaleeniHome> createState() => _DaleeniHomeState();
}

class _DaleeniHomeState extends State<DaleeniHome> {
  static const LatLng nasiriyah = LatLng(31.05799, 46.25726);
  final MapController _map = MapController();
  final TextEditingController _destination = TextEditingController();
  LatLng _current = nasiriyah;
  List<LatLng> _route = [];
  bool _busy = false;
  String _status = 'الخريطة جاهزة — حرّكها وحدد وجهتك';
  String? _routeSummary;

  @override
  void dispose() {
    _destination.dispose();
    super.dispose();
  }

  Future<void> _locateMe() async {
    setState(() {
      _busy = true;
      _status = 'جارٍ تحديد موقعك...';
    });
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) throw Exception('فعّل خدمة الموقع GPS من إعدادات الهاتف.');
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        throw Exception('اسمح لتطبيق دلّيني بالوصول إلى الموقع من إعدادات التطبيق.');
      }
      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
      );
      final point = LatLng(p.latitude, p.longitude);
      if (!mounted) return;
      setState(() {
        _current = point;
        _route = [];
        _routeSummary = null;
        _status = 'تم تحديد موقعك';
      });
      _map.move(point, 15);
    } catch (e) {
      if (mounted) setState(() => _status = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _findRoute() async {
    final query = _destination.text.trim();
    if (query.isEmpty) {
      setState(() => _status = 'اكتب اسم المكان أو العنوان أولاً.');
      return;
    }
    setState(() {
      _busy = true;
      _status = 'جارٍ البحث عن الوجهة والمسار...';
      _route = [];
      _routeSummary = null;
    });
    try {
      // Nominatim public geocoder; use modestly and avoid repeated bulk requests.
      final searchUri = Uri.https('nominatim.openstreetmap.org', '/search', {
        'q': '$query, Iraq',
        'format': 'jsonv2',
        'limit': '1',
      });
      final searchResponse = await http.get(searchUri, headers: {
        'User-Agent': 'DaleeniIraq/1.0 (navigation app prototype)',
        'Accept-Language': 'ar',
      });
      if (searchResponse.statusCode != 200) {
        throw Exception('تعذّر البحث الآن. جرّب مرة ثانية.');
      }
      final places = jsonDecode(searchResponse.body) as List<dynamic>;
      if (places.isEmpty) throw Exception('ما لكيت المكان. جرّب اسم أوضح.');
      final place = places.first as Map<String, dynamic>;
      final destination = LatLng(
        double.parse(place['lat'] as String),
        double.parse(place['lon'] as String),
      );

      // OSRM demo routing service; suitable for testing, not a guaranteed production SLA.
      final routeUri = Uri.https(
        'router.project-osrm.org',
        '/route/v1/driving/${_current.longitude},${_current.latitude};${destination.longitude},${destination.latitude}',
        {'overview': 'full', 'geometries': 'geojson', 'steps': 'false'},
      );
      final routeResponse = await http.get(routeUri, headers: {
        'User-Agent': 'DaleeniIraq/1.0',
      });
      if (routeResponse.statusCode != 200) {
        throw Exception('تعذّر جلب المسار الآن. حاول لاحقاً.');
      }
      final data = jsonDecode(routeResponse.body) as Map<String, dynamic>;
      if (data['code'] != 'Ok' || (data['routes'] as List).isEmpty) {
        throw Exception('ماكو مسار متاح إلى هالوجهة.');
      }
      final route = (data['routes'] as List).first as Map<String, dynamic>;
      final coords = (route['geometry']['coordinates'] as List)
          .map((c) => LatLng((c[1] as num).toDouble(), (c[0] as num).toDouble()))
          .toList();
      final km = ((route['distance'] as num).toDouble() / 1000);
      final minutes = ((route['duration'] as num).toDouble() / 60).round();
      if (!mounted) return;
      setState(() {
        _route = coords;
        _routeSummary = '${km.toStringAsFixed(1)} كم • نحو $minutes دقيقة';
        _status = 'تم العثور على مسار';
      });
      final bounds = LatLngBounds.fromPoints([_current, destination, ...coords]);
      _map.fitCamera(CameraFit.bounds(
        bounds: bounds,
        padding: const EdgeInsets.fromLTRB(42, 160, 42, 150),
      ));
    } catch (e) {
      if (mounted) setState(() => _status = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showReports() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('بلّغ عن الطريق', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('هذه الخيارات حالياً واجهة محلية فقط؛ البلاغات المشتركة تحتاج خادماً وقاعدة بيانات.'),
              const SizedBox(height: 12),
              for (final item in ['حادث مروري', 'ازدحام', 'حفرة أو طريق متضرر', 'خطر على الطريق'])
                ListTile(
                  leading: const Icon(Icons.report_outlined, color: Color(0xFF1267E8)),
                  title: Text(item),
                  onTap: () {
                    Navigator.pop(context);
                    ScaffoldMessenger.of(this.context).showSnackBar(
                      SnackBar(content: Text('اخترت: $item — لم يُرسل بلاغ عام بعد.')),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Stack(
          children: [
            FlutterMap(
              mapController: _map,
              options: const MapOptions(
                initialCenter: nasiriyah,
                initialZoom: 13,
                minZoom: 4,
                maxZoom: 18,
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.daleeni.iraq',
                ),
                if (_route.isNotEmpty)
                  PolylineLayer(polylines: [
                    Polyline(points: _route, strokeWidth: 6, color: const Color(0xFF1267E8)),
                  ]),
                MarkerLayer(markers: [
                  Marker(
                    point: _current,
                    width: 48,
                    height: 48,
                    child: const Icon(Icons.my_location, color: Color(0xFF1267E8), size: 34),
                  ),
                ]),
                const RichAttributionWidget(
                  attributions: [TextSourceAttribution('© OpenStreetMap contributors')],
                ),
              ],
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
                child: Column(
                  children: [
                    Material(
                      elevation: 5,
                      borderRadius: BorderRadius.circular(22),
                      color: Colors.white,
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 44, height: 44,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFEAF1FF),
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  child: const Icon(Icons.navigation_rounded, color: Color(0xFF1267E8), size: 28),
                                ),
                                const SizedBox(width: 10),
                                const Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('دلّيني', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                                      Text('دربك علينا، توصَل بالسلامة', style: TextStyle(color: Colors.black54, fontSize: 12)),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  tooltip: 'موقعي',
                                  onPressed: _busy ? null : _locateMe,
                                  icon: const Icon(Icons.my_location_rounded, color: Color(0xFF1267E8)),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            TextField(
                              controller: _destination,
                              textInputAction: TextInputAction.search,
                              onSubmitted: (_) => _findRoute(),
                              decoration: InputDecoration(
                                hintText: 'وين تريد تروح؟ مثال: مستشفى الناصرية',
                                prefixIcon: const Icon(Icons.search),
                                filled: true,
                                fillColor: const Color(0xFFF3F6FA),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15),
                                  borderSide: BorderSide.none,
                                ),
                              ),
                            ),
                            const SizedBox(height: 9),
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton.icon(
                                onPressed: _busy ? null : _findRoute,
                                icon: const Icon(Icons.alt_route),
                                label: const Text('اعرض الطريق'),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const Spacer(),
                    if (_status.isNotEmpty || _routeSummary != null)
                      Container(
                        width: double.infinity,
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(13),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.96),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 12)],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (_busy) const LinearProgressIndicator(),
                            Text(_status, style: const TextStyle(fontWeight: FontWeight.w600)),
                            if (_routeSummary != null) ...[
                              const SizedBox(height: 4),
                              Text(_routeSummary!, style: const TextStyle(color: Color(0xFF1267E8), fontWeight: FontWeight.bold)),
                            ],
                          ],
                        ),
                      ),
                    Material(
                      elevation: 6,
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _NavAction(icon: Icons.map_outlined, label: 'الخريطة', onTap: () => _map.move(_current, 13)),
                            _NavAction(icon: Icons.my_location, label: 'موقعي', onTap: _locateMe),
                            _NavAction(icon: Icons.campaign_outlined, label: 'بلاغ طريق', onTap: _showReports),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavAction extends StatelessWidget {
  const _NavAction({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(14),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: const Color(0xFF1267E8)),
          const SizedBox(height: 3),
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
        ],
      ),
    ),
  );
}
